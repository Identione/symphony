---
name: Linear Simulator
colors:
  surface: '#121315'
  surface-dim: '#121315'
  surface-bright: '#38393a'
  surface-container-lowest: '#0d0e0f'
  surface-container-low: '#1b1c1d'
  surface-container: '#1f2021'
  surface-container-high: '#292a2b'
  surface-container-highest: '#343536'
  on-surface: '#e3e2e3'
  on-surface-variant: '#c6c5d5'
  inverse-surface: '#e3e2e3'
  inverse-on-surface: '#303032'
  outline: '#908f9e'
  outline-variant: '#454652'
  surface-tint: '#bdc2ff'
  primary: '#bdc2ff'
  on-primary: '#121f8b'
  primary-container: '#5e6ad2'
  on-primary-container: '#fdfaff'
  inverse-primary: '#4854bb'
  secondary: '#c2c7d0'
  on-secondary: '#2c3138'
  secondary-container: '#444951'
  on-secondary-container: '#b4b9c2'
  tertiary: '#ffb867'
  on-tertiary: '#482900'
  tertiary-container: '#a56500'
  on-tertiary-container: '#fffaf8'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dfe0ff'
  primary-fixed-dim: '#bdc2ff'
  on-primary-fixed: '#000965'
  on-primary-fixed-variant: '#2e3aa2'
  secondary-fixed: '#dee3ec'
  secondary-fixed-dim: '#c2c7d0'
  on-secondary-fixed: '#171c23'
  on-secondary-fixed-variant: '#42474f'
  tertiary-fixed: '#ffddbb'
  tertiary-fixed-dim: '#ffb867'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#121315'
  on-background: '#e3e2e3'
  surface-variant: '#343536'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: '0'
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '450'
    lineHeight: 16px
    letterSpacing: '0'
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 24px
  gutter: 16px
  element-gap: 8px
  section-gap: 32px
---

## Brand & Style
The brand personality is precise, technical, and high-performance. This design system targets developers and power users who prioritize information density and system clarity over decorative elements. 

The aesthetic is **High-Contrast Minimalism** mixed with **Functional Modernism**. It utilizes a "Near-Black" dark mode to reduce eye strain during long sessions while maintaining a rigorous structural grid. The emotional response should be one of "focused control"—where the UI recedes to let data and logic take center stage.

## Colors
The palette is engineered for a professional developer environment. 

- **Backgrounds:** The primary workspace uses `#08090A`. Surfaces like sidebars and cards use `#16171B` to create subtle depth.
- **Accents:** Linear Indigo (`#5E6AD2`) is used sparingly for primary actions and active states to maintain focus.
- **Semantic Colors:** Used strictly for status indication. Success, Warning, and Error colors are desaturated slightly to prevent "vibration" against the dark background.
- **Borders:** All structural divisions use a 1px hairline (`#23252A`). Avoid using shadows for separation; rely on border contrast and surface shifts.

## Typography
This design system utilizes a dual-font strategy to distinguish between UI controls and system data.

- **Inter:** The workhorse for all interface elements, headings, and body text. Use tighter tracking for headings and standard tracking for body copy.
- **JetBrains Mono:** Reserved for "technical strings"—this includes IDs (e.g., `UUID`), Git hashes, code snippets, and terminal output.
- **Scale:** Maintain a small base size (14px) for body text to allow for high data density. Labels and status pills should use 11px uppercase to maximize horizontal space.

## Layout & Spacing
The layout follows a **Fluid Grid** model with fixed-width sidebars. 

- **Density:** The design is "tight but generous." Use 8px (`2u`) for internal component spacing and 16px (`4u`) for layout gutters.
- **Desktop First:** The primary experience is optimized for 1440px displays. Use a 12-column grid for main content areas.
- **Sidebars:** Fixed at 240px or 280px. Content within sidebars should use a vertical rhythm of 4px and 8px.
- **Margins:** Global container padding is set to 24px to provide a "frame" for the dense data tables and graphs inside.

## Elevation & Depth
In this dark, minimal environment, elevation is expressed through **Tonal Layers** rather than shadows.

- **Base (Level 0):** `#08090A` - The main application canvas.
- **Surface (Level 1):** `#16171B` - Cards, modals, and sidebars. 
- **Interaction:** Hover states on surface elements should lighten the background by 2-4% or add a subtle inner glow.
- **Borders:** Every elevated surface must have a 1px border of `#23252A`. This "hairline" defines the structure in the absence of heavy drop shadows.
- **Overlays:** Modals and dropdowns use a slight backdrop blur (8px-12px) to maintain context without visual clutter.

## Shapes
The shape language is disciplined and geometric.

- **Cards:** 8px corner radius. This provides a modern, slightly soft container for data-heavy views.
- **Buttons:** 6px corner radius. This sharper radius communicates precision and aligns with the technical nature of the tool.
- **Status Pills/Badges:** Fully rounded (pill-shaped) to distinguish them from interactive buttons and structural containers.
- **Inputs:** Match the button radius (6px) for consistency in forms.

## Components
- **Buttons:** Primary buttons use a solid Indigo background with White text. Secondary buttons use a Ghost style (border only) or a subtle Gray-Scale fill. Height should be fixed at 32px for standard and 28px for compact views.
- **Status Pills:** Small (11px text), uppercase, with a 2px dot of the status color (e.g., Healthy Green) next to the label.
- **Input Fields:** Background should be `#08090A` (inset from the surface) with a 1px `#23252A` border. Active state uses an Indigo border.
- **Data Tables:** No vertical borders. Use 1px horizontal dividers. Header text should be `label-caps` in Muted Slate.
- **Monospace Tokens:** Any system-generated ID should be wrapped in a subtle code-block style: `background: #23252A`, `font-family: JetBrains Mono`, `padding: 2px 4px`.
- **Cards:** Use for logical grouping. Ensure all cards have a 1px border. Do not use cards within cards; use horizontal dividers or spatial grouping instead.